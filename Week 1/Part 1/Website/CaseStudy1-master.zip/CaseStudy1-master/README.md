# CaseStudy1
First sample of the case study
